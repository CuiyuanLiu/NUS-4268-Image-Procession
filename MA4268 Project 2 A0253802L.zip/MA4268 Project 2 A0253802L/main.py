from procession import *
import numpy
import cv2

def dwt2d(im: np.ndarray, lvl: int, tap: int):
    processer = image_processor(im)
    return processer.dwt_run(im, lvl, tap, True)
    
def idwt2d(im: np.ndarray, lvl: int, tap: int):
    processer = image_processor(im)
    return processer.dwt_run(im, lvl, tap, False)

def test():
    name = "sample512.png"
    ipt_img = cv2.imread(name)
    opt_img = dwt2d(ipt_img, 2, 2)
    mathsTool.save_image([opt_img], "tap2_lvl2_sample512.png")

test()