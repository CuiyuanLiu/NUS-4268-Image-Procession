import cv2
import numpy as np
import os
from datetime import datetime
from scipy import signal


class mathsTool():    
    """__summary__
    A class to store the supporting functions.
    def save_image(ipt_Lst: list, tag: str), Function to save the image as jpg by using np.array as input.
    """
    # Function to save the image under the current directory.
    def save_image(ipt_Lst: list, tag: str):
        if not os.path.exists("result"): os.mkdir("result")
        curr_time = "".join(list(str(x) for x in [
            datetime.now().year, datetime.now().month, datetime.now().day, datetime.now().hour, datetime.now().minute, tag
        ]))
        if not os.path.exists("result/" + curr_time): os.mkdir("result/" + curr_time)
        for item in enumerate(ipt_Lst):
            try: cv2.imwrite("/" .join(['result', curr_time, str(item[0]) + '_color_image.png']), item[1])
            except Exception as err: print("Error!", err)
    
    # Function to split an image.
    def split(range1: list, range2: list, ipt_mat: list):
        return list(row[range1[0]: range1[1]] for row in ipt_mat[range2[0]: range2[1]])

class image_processor():
    """__summary__
    This is a class to store functions used to do DWT.
    """
    # Initial setting function is only the completions. 
    def __init__(self, src_image: np.ndarray):
        self.src_image = src_image
        self.tap2_coords_h = list(x/np.sqrt(2) for x in [1, 1])
        self.tap2_coords_g = list(x/np.sqrt(2) for x in [1, -1])
        self.tap4_coords_h = list(x/np.sqrt(2) for x in [0.6830127, 1.1830127, 0.3169873, -0.1830127])
        self.tap4_coords_g = list(x/np.sqrt(2) for x in [0.1830127, 0.3169873, -1.1830127, 0.6830127])
    
    # tap2 calculation method.
    def tap2_calc(self, ipt_mat: list, direction: bool):
        # function to count row value by coeff.
        def count_row_part(coeff: list, input_vec: list):
            result_vec = []
            counter, step = 0, 2
            while (counter < len(input_vec)):
                ipt_lst = [input_vec[counter], input_vec[counter + 1]]
                try: result_vec.append(np.dot(np.array(ipt_lst), np.array(coeff)))
                except Exception as err: print(err, counter, len(input_vec))
                counter = counter + step
            return result_vec
        
        # function to count a seperate matrix.
        def get_seperate_mat(ipt_mat: list, coeff_mat: list):
            result_lst = []
            counter_x, counter_y, step_y = 0, 0, 2
            for counter_y in range(0, len(ipt_mat), 2):
                curr_row1 = count_row_part(coeff_mat[0], ipt_mat[counter_y])
                curr_row2 = count_row_part(coeff_mat[1], ipt_mat[counter_y + 1])
                result_lst.append(list((curr_row1[i] + curr_row2[i]) for i in range(0, len(curr_row1))))
            return result_lst
        
        # function to colloct points from four seperate blocks and reverse.
        def reverse_image(ipt_mat, th):
            n_ipt_mat = []
            counter_y = 0
            while (counter_y < th):
                block_1_Lst, block_2_Lst = [], []
                counter_x = 0
                while (counter_x < th):
                    block_1_Lst = block_1_Lst + [ipt_mat[counter_y][counter_x], ipt_mat[counter_y][counter_x + th]]
                    block_2_Lst = block_2_Lst + [ipt_mat[counter_y + th][counter_x], ipt_mat[counter_y + th][counter_x + th]]
                    counter_x = counter_x + 1
                n_ipt_mat = n_ipt_mat + [block_1_Lst, block_2_Lst]
                counter_y = counter_y + 1
            return n_ipt_mat

        if (len(ipt_mat) % 2 != 0 or len(ipt_mat) == 0): return ipt_mat
        th = int(len(ipt_mat) / 2)
        result_list = [[]] * len(ipt_mat)
        vec_h, vec_g = np.array([self.tap2_coords_h]), np.array([self.tap2_coords_g])

        # if direction is True, process the dwt
        # if direction is False, process the idwt, regenrate the input matrix.
        if (direction): pass
        elif (not direction): ipt_mat = reverse_image(ipt_mat, th)
            
        matH0 = get_seperate_mat(ipt_mat, list(np.dot(np.transpose(vec_h), vec_h)))
        matG1 = get_seperate_mat(ipt_mat, list(np.dot(np.transpose(vec_g), vec_h)))
        matG2 = get_seperate_mat(ipt_mat, list(np.dot(np.transpose(vec_h), vec_g)))
        matG3 = get_seperate_mat(ipt_mat, list(np.dot(np.transpose(vec_g), vec_g)))
        
        for counter in range(0, th):
            result_list[counter] = (matH0[counter] + matG1[counter])
            result_list[counter + th] = (matG2[counter] + matG3[counter])
        if (not direction): result_list = reverse_image(result_list, th)
        return result_list
    
    # tap4 calculation method.
    def tap4_calc(self, ipt_mat: list, direction: bool):        
        # function to count a seperate matrix.
        def get_seperate_mat(ipt_mat: list, coeff_mat: list):
            result_lst = []
            counter_x, counter_y, step_y = 0, 0, 4
            for counter_y in range(0, len(ipt_mat), step_y):
                # curr_result_Lst = [[]] * step_y
                curr_result_Lst = []
                for counter_x in range(0, len(ipt_mat), step_y):
                    curr_block = mathsTool.split([counter_x, counter_x + step_y], [counter_y, counter_y + step_y], ipt_mat)
                    result = signal.convolve2d(np.array(curr_block), np.array(coeff_mat), 'valid')
                    # for c in range(step_y): curr_result_Lst[c] = curr_result_Lst[c] + list(result_block[c])
                    curr_result_Lst = curr_result_Lst + [result[0][0], result[0][0]]
                result_lst = result_lst + [curr_result_Lst, curr_result_Lst]
            return result_lst

        if (len(ipt_mat) % 2 != 0 or len(ipt_mat) == 0): return ipt_mat
        th = int(len(ipt_mat) / 2)
        result_list = [[]] * int(len(ipt_mat))
        vec_h, vec_g = np.array([self.tap4_coords_h]), np.array([self.tap4_coords_g])

        # if direction is True, process the dwt
        # if direction is False, process the idwt, regenrate the input matrix.
        if (direction):
            matH0 = get_seperate_mat(ipt_mat, list(np.dot(np.transpose(vec_h), vec_h)))
            matG1 = get_seperate_mat(ipt_mat, list(np.dot(np.transpose(vec_g), vec_h)))
            matG2 = get_seperate_mat(ipt_mat, list(np.dot(np.transpose(vec_h), vec_g)))
            matG3 = get_seperate_mat(ipt_mat, list(np.dot(np.transpose(vec_g), vec_g)))
            
            for counter in range(0, th):
                result_list[counter] = (matH0[counter] + matG1[counter])
                result_list[counter + th] = (matG2[counter] + matG3[counter])
            return result_list
        
        else: 
            return self.tap2_calc(ipt_mat, False)
        

    # Function implement pywt for testing.
    def pywt_single_run(self, im: list, direction: bool, tap: int):
        colour_size, image_width, image_height = len(im[0][0]), len(im[0]), len(im)
        im_result_lst = [[[] * colour_size] * image_width] * image_height
        temp_mat_result_1, temp_mat_result_2 = [], []
        
        # Seperating pixels into list in parallel.
        for index in range(colour_size):
            curr_mat = []
            for row in im: curr_mat.append(list(pixel[index] for pixel in row))
            temp_mat_result_1.append(curr_mat)
        
        # Do procession for three colours in specific tag.
        for index in range(colour_size): 
            if (tap == 2):
                temp_mat_result_2.append(self.tap2_calc(temp_mat_result_1[index], direction))
            else:
                temp_mat_result_2.append(self.tap4_calc(temp_mat_result_1[index], direction))
        
        result = []
        counter_y = 0
        image_width, image_height = len(temp_mat_result_2[0][0]), len(temp_mat_result_2[0])
        while (counter_y < image_height):
            counter_x = 0
            curr_row = []
            while(counter_x < image_width):
                curr_row.append([
                    temp_mat_result_2[0][counter_y][counter_x],
                    temp_mat_result_2[1][counter_y][counter_x],
                    temp_mat_result_2[2][counter_y][counter_x]
                ])
                counter_x = counter_x + 1
            counter_y = counter_y + 1
            result.append(curr_row)
        return result

    # function to run dwt
    def dwt_run(self, im: np.ndarray, lvl: int, tap: int, direction: bool):
        curr_lvl = 0
        rst_im = list(im)
        while curr_lvl < lvl:
            rst_im = self.pywt_single_run(rst_im, direction, tap)   
            curr_lvl = curr_lvl + 1
        return np.array(rst_im)
            
#########################################################################################################
"""
def test_spliting(processor: image_processor):
    splited_image_Lst = processor.split_image(processor.src_image, 128, 64)
    mathsTool.save_image(splited_image_Lst, "")

def test():
    # A comparaing version saved as name in cv2 to see effects.
    # The image to list is displayed in rows.
    name = "sample512.png"
    ipt_img = cv2.imread(name)
    # ipt_img = list(row[0: 8] for row in ipt_img)[0: 8]
    # print(ipt_img)
    processer = image_processor(ipt_img)
    tap2_result = processer.dwt_run(ipt_img, 1, 4, True)
    opt_img = np.array(tap2_result)
    mathsTool.save_image([opt_img], "ss_zzhh")
"""