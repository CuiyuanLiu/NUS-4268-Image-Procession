Dear Professor,
First I need to say sorry because the time is quite urgent for me to prepare this assignment and the final exams, and it is quite hard
to implement the coding part for the assignment, hence it would look like not such perfect. 
By using python main.py could do a simple test for it. You could alter the tap parameter and the level parameters there also. And please
check the result generated in result folder.

Thank you so much for reviewing this scripts.